import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {User} from './users';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html'
})
export class SignupFormComponent implements OnInit {
  genderList: string[];
  signupForm: FormGroup;
  user:User;

  ngOnInit() {
    this.genderList = ['Male', 'Female', 'Others'];

    this.signupForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]),
      password: new FormGroup({
        pwd: new FormControl('', [Validators.required, Validators.minLength(8)]),
        confirmPwd: new FormControl('', [Validators.required, Validators.minLength(8)])
      }),
      gender: new FormControl('', Validators.required),
      //requiredTrue so that the terms field is valid only if checked
      terms: new FormControl('', Validators.requiredTrue)
    })
  }
  
  //To get rid of the long chain of method names signupForm.controls.email.invalid, 
  //Using these getter methods you can simply write as email.invalid
  get email() { return this.signupForm.get('email'); }
  get password() { return this.signupForm.get('password'); }
  get gender() { return this.signupForm.get('gender'); }
  get terms() { return this.signupForm.get('terms'); }

  public onFormSubmit() {
        if(this.signupForm.valid) {
            this.user = this.signupForm.value;
            console.log(this.user);            
        }
    }
}